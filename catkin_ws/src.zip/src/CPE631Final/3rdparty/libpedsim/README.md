# pedsim
standalone pedsim library (pedestrian simulator using social force model)

Based on original library from Christian Gloor [http://pedsim.silmaril.org/](http://pedsim.silmaril.org/)
